Here are your keys.
These verify and allow you to make requests to the Twitter API.

API key

```bash
aAofHmy8se1EaWDLOAJ7JVA3h
```

API secret key
```
o2CC5TGvIRWn2sLytmGpdIQvZkTYWPakkvDrZ8iAnI0jpIZrjS
```

Bearer token
```
AAAAAAAAAAAAAAAAAAAAAKLXFwEAAAAAAVIRbBcN09e7X8AcD%2FiUOiokXww%3Dya0axpYZ52YNy2G6WPoxSYUS5PLUEuMWPpCcpiWX13hOx13xiS```
